# SecureBank Honeypot

Fake net-banking portal that records attacker behaviour (logins, transfers, forced browsing) and scores risk.

## Run
    pip install -r requirements.txt
    python app.py

- Bank login (bait account): http://127.0.0.1:5000  ->  `vedu` / `12345`
- Admin console: http://127.0.0.1:5000/admin/login (password is printed in the terminal on start)

## Config (optional env vars)
`ADMIN_PASSWORD`, `BAIT_USER`, `BAIT_PASS`, `SECRET_KEY`, `HOST`, `PORT`

## Data
All events go to `data/events.jsonl` (one JSON object per line). Export CSVs from the admin console.
Only expose beyond localhost inside an isolated network/VM.
