const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
$$('[data-toggle]').forEach(b=>b.onclick=()=>{const i=$(b.dataset.toggle);i.type=i.type==='password'?'text':'password';b.textContent=i.type==='password'?'Show':'Hide'});
const tf=$('#transfer');
if(tf){
  const a=$('[name=account]',tf),c=$('[name=confirm_account]',tf),h=$('#mismatch'),amt=$('[name=amount]',tf);
  const chk=()=>{h.textContent=c.value&&a.value!==c.value?'Account numbers do not match':'';return!h.textContent};
  a.oninput=c.oninput=chk;
  amt.oninput=()=>{$('#words').textContent=amt.value?'₹ '+Number(amt.value).toLocaleString('en-IN'):''};
  tf.onsubmit=e=>{if(!chk()){e.preventDefault();c.focus();return}
    const b=$('button[type=submit]',tf);b.disabled=true;b.innerHTML='<span class="spin"></span> Processing securely…'};
}
$$('.pw').forEach(p=>p.onclick=()=>{const t=p.textContent;p.textContent=p.dataset.pw;p.dataset.pw=t});
const tabs=$$('.tab');
if(tabs.length){
  let cur=tabs[0].dataset.t;
  const filter=()=>{const q=$('#q').value.toLowerCase();$$('#'+cur+' tbody tr').forEach(r=>r.hidden=!!q&&!r.textContent.toLowerCase().includes(q))};
  const show=()=>{$$('.pane').forEach(p=>p.hidden=p.id!==cur);tabs.forEach(t=>t.classList.toggle('on',t.dataset.t===cur));filter()};
  tabs.forEach(t=>t.onclick=()=>{cur=t.dataset.t;show()});$('#q').oninput=filter;show();
}
