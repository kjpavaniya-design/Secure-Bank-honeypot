"""SecureBank honeypot - fake banking portal that records attacker behaviour."""
import csv, io, json, os, secrets, threading
from collections import Counter
from datetime import datetime, timedelta
from functools import wraps
from pathlib import Path

from flask import Flask, Response, abort, redirect, render_template, request, session, url_for

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
DATA.mkdir(exist_ok=True)
EVENTS, KEY_FILE, LOCK = DATA / "events.jsonl", DATA / ".secret_key", threading.Lock()

BAIT = {os.environ.get("BAIT_USER", "vedu"): os.environ.get("BAIT_PASS", "12345")}
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD") or secrets.token_urlsafe(9)
WINDOW, FAILS = timedelta(minutes=15), {}
BALANCE = 245630.45
DEMO = [("22 Jul 2026", "TXN1001", "Salary Credit", "Credit", 42000, "Success"),
        ("21 Jul 2026", "TXN1002", "Amazon Purchase", "Debit", 1240, "Success"),
        ("20 Jul 2026", "TXN1003", "Netflix Subscription", "Debit", 649, "Success"),
        ("18 Jul 2026", "TXN1004", "Electricity Bill", "Debit", 2150, "Success"),
        ("15 Jul 2026", "TXN1005", "Interest Credit", "Credit", 530, "Success")]


def _secret():
    if os.environ.get("SECRET_KEY"):
        return os.environ["SECRET_KEY"]
    if not KEY_FILE.exists():
        KEY_FILE.write_text(secrets.token_hex(32))
    return KEY_FILE.read_text().strip()


app = Flask(__name__)
app.secret_key = _secret()
clip = lambda s, n=200: (s or "")[:n]


# ---------- structured event log (JSON Lines: immune to '|' / newline log injection) ----------
def log(kind, **fields):
    e = {"ts": datetime.now().isoformat(timespec="seconds"), "kind": kind, "ip": request.remote_addr,
         "ua": clip(request.headers.get("User-Agent"), 300), **fields}
    with LOCK, EVENTS.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(e, ensure_ascii=False) + "\n")


def events(kind=None):
    out = []
    if EVENTS.exists():
        with LOCK, EVENTS.open(encoding="utf-8") as fh:
            for line in fh:
                try:
                    e = json.loads(line)
                except ValueError:
                    continue
                if kind is None or e.get("kind") == kind:
                    out.append(e)
    return out[::-1]  # newest first


def alert(level, attack, score, user="-", detail=""):
    log("alert", level=level, attack=attack, score=score, user=user, detail=detail)


def risk(n):
    return (10, "LOW") if n <= 1 else (30, "MEDIUM") if n == 2 else (60, "HIGH") if n <= 4 else (80, "CRITICAL")


def _group(i):
    if len(i) <= 3:
        return i
    head, tail, parts = i[:-3], i[-3:], []
    while len(head) > 2:
        parts.insert(0, head[-2:]); head = head[:-2]
    return ",".join(([head] if head else []) + parts + [tail])


@app.template_filter("inr")
def inr(v):
    try:
        i, d = f"{abs(float(v)):.2f}".split(".")
    except (TypeError, ValueError):
        return str(v)
    return "₹" + _group(i) + ("" if d == "00" else "." + d)


def bank_page(f):
    @wraps(f)
    def w(*a, **k):
        if "username" not in session:
            alert("MEDIUM", "Unauthenticated Access", 40, detail=request.path)
            return redirect(url_for("login"))
        return f(*a, **k)
    return w


def admin_only(f):
    @wraps(f)
    def w(*a, **k):
        return f(*a, **k) if session.get("admin") else redirect(url_for("admin_login"))
    return w


def page(template, activity, **ctx):
    log("activity", user=session["username"], action=activity)
    return render_template(template, username=session["username"], **ctx)


def txn_rows():
    rows = [dict(date=d, id=i, desc=s, type=t, amount=a, status=st) for d, i, s, t, a, st in DEMO]
    sent = events("transfer")[::-1]
    live = [dict(date=e["ts"][:10], id=f"TXN{2000 + n}", desc="Transfer to " + e.get("beneficiary", "?"),
                 type="Debit", amount=e.get("amount", 0), status="Pending") for n, e in enumerate(sent, 1)]
    return live[::-1][:20] + rows


# ---------- bank pages ----------
@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        u, p = clip(request.form.get("username")).strip(), clip(request.form.get("password"))
        ip, now = request.remote_addr, datetime.now()
        if u and BAIT.get(u) == p:
            FAILS.pop(ip, None)
            session.clear(); session["username"] = u
            log("login", user=u, password=p, ok=True)
            return redirect(url_for("dashboard"))
        hist = [t for t in FAILS.get(ip, []) if now - t < WINDOW] + [now]
        FAILS[ip] = hist
        score, level = risk(len(hist))
        log("login", user=u, password=p, ok=False, attempts=len(hist), level=level, score=score)
        if len(hist) >= 3:
            alert(level, "Possible Brute Force", score, u, f"{len(hist)} failed attempts in 15 min")
        return render_template("login.html", error="Invalid username or password."), 401
    return render_template("login.html")


@app.route("/dashboard")
@bank_page
def dashboard():
    return page("dashboard.html", "Viewed Dashboard", balance=BALANCE, txns=txn_rows()[:5])


@app.route("/balance")
@bank_page
def balance():
    return page("balance.html", "Viewed Balance", balance=BALANCE)


@app.route("/transactions")
@bank_page
def transactions():
    return page("transactions.html", "Viewed Transactions", txns=txn_rows())


@app.route("/profile")
@bank_page
def profile():
    return page("profile.html", "Viewed Profile")


@app.route("/transfer", methods=["GET", "POST"])
@bank_page
def transfer():
    if request.method == "GET":
        return page("transfer.html", "Viewed Transfer", form={})
    f = {k: clip(request.form.get(k)) for k in ("beneficiary", "account", "confirm_account", "ifsc", "amount", "remarks")}
    user = session["username"]
    log("transfer", user=user, **f)
    try:
        amount = float(f["amount"])
    except ValueError:
        amount = 0
    if amount > 50000:
        alert("HIGH", "Suspicious High-Value Transfer", 90, user, f"Amount: ₹{f['amount']}")
    if f["account"] != f["confirm_account"]:
        alert("HIGH", "Account Number Mismatch", 70, user, "Account numbers do not match")
        return render_template("transfer.html", username=user, form=f, error="Account numbers do not match."), 400
    done = dict(ref="SB" + secrets.token_hex(5).upper(), amount=f["amount"], to=f["beneficiary"])
    return render_template("transfer.html", username=user, form={}, done=done)


@app.route("/logout")
def logout():
    if "username" in session:
        log("activity", user=session["username"], action="Logout")
    session.pop("username", None)
    return redirect(url_for("login"))


# ---------- admin console ----------
@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        if secrets.compare_digest(request.form.get("password", "").encode(), ADMIN_PASSWORD.encode()):
            session["admin"] = True
            return redirect(url_for("admin"))
        alert("MEDIUM", "Admin Login Failed", 50, detail="Wrong admin password")
        return render_template("login.html", admin=True, error="Incorrect admin password."), 401
    return render_template("login.html", admin=True)


@app.route("/admin")
@admin_only
def admin():
    lg, tr, al = events("login"), events("transfer"), events("alert")
    bad = [e for e in lg if not e.get("ok")]
    top = lambda key: Counter(clip(e.get(key), 40) for e in bad).most_common(5)
    stats = dict(logins=len(lg), failed=len(bad), transfers=len(tr), alerts=len(al),
                 critical=sum(a.get("level") == "CRITICAL" for a in al))
    return render_template("admin.html", admin_page=True, logins=lg[:300], transfers=tr[:300], alerts=al[:300],
                           stats=stats, top_ips=top("ip"), top_users=top("user"), top_pw=top("password"))


@app.route("/admin/logout")
def admin_logout():
    session.pop("admin", None)
    return redirect(url_for("admin_login"))


@app.route("/admin/export/<kind>.csv")
@admin_only
def export(kind):
    if kind not in ("login", "transfer", "alert", "activity"):
        abort(404)
    rows = events(kind)[::-1]
    head = ["ts", "kind", "ip"]
    cols = head + sorted({k for r in rows for k in r} - set(head))
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(cols)
    for r in rows:  # neutralise spreadsheet formula injection
        w.writerow([("'" + str(r.get(c, ""))) if str(r.get(c, ""))[:1] in "=+-@" else r.get(c, "") for c in cols])
    return Response(buf.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": f"attachment; filename={kind}_logs.csv"})


@app.errorhandler(404)
def not_found(_):
    return render_template("login.html", error="Page not found."), 404


if __name__ == "__main__":
    if not os.environ.get("ADMIN_PASSWORD"):
        print(f"\n  Admin console: http://127.0.0.1:5000/admin/login   password: {ADMIN_PASSWORD}\n")
    app.run(host=os.environ.get("HOST", "127.0.0.1"), port=int(os.environ.get("PORT", 5000)), debug=False)
